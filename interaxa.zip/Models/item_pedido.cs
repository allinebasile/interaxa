﻿namespace interaxa.Models
{
    public class item_pedido
    {
        public int idpedido { get; set; }
        public int idLanche { get; set; }
        public string descricaoLanche { get; set; }

    }
}