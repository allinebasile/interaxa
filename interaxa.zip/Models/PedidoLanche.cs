﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace interaxa.Models
{
    public class PedidoLanche
    {
        public int idpedido { get; set; }
        public int iditem { get; set; }
        public int idlanche { get; set; }
        public string descricao { get; set; }
    }
}