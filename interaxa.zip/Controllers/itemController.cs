﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using interaxa.Models;

namespace interaxa.Controllers
{
    public class itemController : Controller
    {
        private DBContext db = new DBContext();

      
        public IEnumerable<PedidoLanche> Lista(int pedido)
        {
         
            try

            {
                string cnnString = "data source=(localdb)\\MSSQLLocalDB;initial catalog=master;integrated security=True;MultipleActiveResultSets=True";

                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "st_ListarLanche";
                cmd.Parameters.AddWithValue("@idpedido", pedido);
                cnn.Open();
                SqlDataReader read = cmd.ExecuteReader();

                List<PedidoLanche> Lanches = new List<PedidoLanche>();
                while (read.Read())
                {
                    PedidoLanche lanche = new PedidoLanche();
                    lanche.iditem = Convert.ToInt32(read["id_Item"]);
                    lanche.idlanche = Convert.ToInt32(read["id_Lanche"]);
                    lanche.idpedido = Convert.ToInt32(read["id_Pedido"]);
                    lanche.descricao = read["descricao"].ToString();
                    Lanches.Add(lanche);
                }
                cnn.Close();
                return Lanches;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public ActionResult Index(int pedido=0)
        {
            List<PedidoLanche> lista = new List<PedidoLanche>();
            lista = Lista(pedido).ToList();
            return View(lista);
        }

        // GET: item/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_item tb_item = db.tb_item.Find(id);
            if (tb_item == null)
            {
                return HttpNotFound();
            }
            return View(tb_item);
        }

        // GET: item/Create
        public ActionResult Create(int pedido=0)
        {
            if (pedido==0) 
            {
                ViewBag.id_pedido = new SelectList(db.tb_pedido, "id_pedido", "id_pedido");
            }
            else
            {
                ViewBag.id_pedido = new SelectList(db.tb_pedido, "id_pedido", "id_pedido",pedido);
            }

            ViewBag.id_lanche = new SelectList(db.tb_lanche, "id_lanche", "descricao");
            return View();
        }

        // POST: item/Create
        // Para proteger-se contra ataques de excesso de postagem, ative as propriedades específicas às quais deseja se associar. 
        // Para obter mais detalhes, confira https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create(int pedido=0, int lanche=0)
        {
            if (ModelState.IsValid)
            {

                string cnnString = "data source=(localdb)\\MSSQLLocalDB;initial catalog=master;integrated security=True;MultipleActiveResultSets=True";

                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "st_incluirItem";
               
                cmd.Parameters.Add("@idPedido", System.Data.SqlDbType.Int);
                cmd.Parameters["@idPedido"].Value = pedido;
                cmd.Parameters.Add("@idLanche", System.Data.SqlDbType.Int);
                cmd.Parameters["@idLanche"].Value = lanche;
                cnn.Open();
                object o = cmd.ExecuteScalar();
                cnn.Close();

            }

         
            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_item tb_item = db.tb_item.Find(id);
            if (tb_item == null)
            {
                return HttpNotFound();
            }
            ViewBag.id_pedido = new SelectList(db.tb_pedido, "id_pedido", "id_pedido", tb_item.id_pedido);
            ViewBag.id_lanche = new SelectList(db.tb_lanche, "id_lanche", "descricao", tb_item.id_lanche);

            return View(tb_item);
        }

        // POST: item/Edit/5
        // Para proteger-se contra ataques de excesso de postagem, ative as propriedades específicas às quais deseja se associar. 
        // Para obter mais detalhes, confira https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_item,id_pedido,id_ingrediente,valor")] tb_item tb_item)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tb_item).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.id_pedido = new SelectList(db.tb_pedido, "id_pedido", "id_pedido", tb_item.id_pedido);
            ViewBag.id_lanche = new SelectList(db.tb_lanche, "id_lanche", "descricao", tb_item.id_lanche);

            return View(tb_item);
        }

       
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_item tb_item = db.tb_item.Find(id);
            if (tb_item == null)
            {
                return HttpNotFound();
            }
            return View(tb_item);
        }

        
        [HttpPost, ActionName("Delete")]
       
        public ActionResult DeleteConfirmed(int id)
        {

            string cnnString = "data source=(localdb)\\MSSQLLocalDB;initial catalog=master;integrated security=True;MultipleActiveResultSets=True";

            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "st_ExcluirLanche";
                      
            cmd.Parameters.Add("@idLanche", System.Data.SqlDbType.Int);
            cmd.Parameters["@idLanche"].Value = id;
            cnn.Open();
            object o = cmd.ExecuteScalar();
            cnn.Close();

         
            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);
          
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
