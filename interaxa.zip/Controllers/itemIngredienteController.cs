﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using interaxa.Models;

namespace interaxa.Controllers
{
    public class itemIngredienteController : Controller
    {
        private DBContext db = new DBContext();

       
        public ActionResult Index(int item=0)
        {
            var tb_item_ingrediente = db.tb_item_ingrediente.Include(t => t.tb_ingrediente).Include(t => t.tb_item);
            return View(tb_item_ingrediente.Where(x => x.id_item == item).ToList());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_item_ingrediente tb_item_ingrediente = db.tb_item_ingrediente.Find(id);
            if (tb_item_ingrediente == null)
            {
                return HttpNotFound();
            }
            return View(tb_item_ingrediente);
        }

      
        public ActionResult Create(int item = 0)
        {
            if (item == 0)
            {
                ViewBag.id_item = new SelectList(db.tb_item, "id_item", "id_item");
            }
            else 
            {
                ViewBag.id_item = new SelectList(db.tb_item, "id_item", "id_item", item);
            }
            ViewBag.id_ingrediente = new SelectList(db.tb_ingrediente, "id_ingrediente", "descricao");
           
            return View();
        }
             
        [HttpPost]
       
        public ActionResult Create(int item = 0, int ingrediente = 0)
        {
            if (ModelState.IsValid)
            {

                string cnnString = "data source=(localdb)\\MSSQLLocalDB;initial catalog=master;integrated security=True;MultipleActiveResultSets=True";
                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "st_customizaLanche";
                               
                cmd.Parameters.Add("@idIngrediente", System.Data.SqlDbType.Int);
                cmd.Parameters["@idIngrediente"].Value = ingrediente;
                cmd.Parameters.Add("@idItem", System.Data.SqlDbType.Int);
                cmd.Parameters["@idItem"].Value = item;
                cnn.Open();
                object o = cmd.ExecuteScalar();
                cnn.Close();

            }


            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);

      
        }

      
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_item_ingrediente tb_item_ingrediente = db.tb_item_ingrediente.Find(id);
            if (tb_item_ingrediente == null)
            {
                return HttpNotFound();
            }
            ViewBag.id_ingrediente = new SelectList(db.tb_ingrediente, "id_ingrediente", "descricao", tb_item_ingrediente.id_ingrediente);
            ViewBag.id_item = new SelectList(db.tb_item, "id_item", "id_item", tb_item_ingrediente.id_item);
            return View(tb_item_ingrediente);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_item_ingrediente,id_item,id_ingrediente,valor,flag_customizado")] tb_item_ingrediente tb_item_ingrediente)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tb_item_ingrediente).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.id_ingrediente = new SelectList(db.tb_ingrediente, "id_ingrediente", "descricao", tb_item_ingrediente.id_ingrediente);
            ViewBag.id_item = new SelectList(db.tb_item, "id_item", "id_item", tb_item_ingrediente.id_item);
            return View(tb_item_ingrediente);
        }

       // GET: itemIngrediente/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_item_ingrediente tb_item_ingrediente = db.tb_item_ingrediente.Find(id);
            if (tb_item_ingrediente == null)
            {
                return HttpNotFound();
            }
            return View(tb_item_ingrediente);
        }

       
        [HttpPost, ActionName("Delete")]
      
        public ActionResult DeleteConfirmed(int id)
        {

            string cnnString = "data source=(localdb)\\MSSQLLocalDB;initial catalog=master;integrated security=True;MultipleActiveResultSets=True";
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnn;
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "st_excluirIngrediente";

            cmd.Parameters.Add("@idIngrediente", System.Data.SqlDbType.Int);
            cmd.Parameters["@idIngrediente"].Value = id;
            cnn.Open();
            object o = cmd.ExecuteScalar();
            cnn.Close();
           
            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
