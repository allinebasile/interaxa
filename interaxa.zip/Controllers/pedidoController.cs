﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using interaxa.Models;

namespace interaxa.Controllers
{
    public class pedidoController : Controller
    {
        private DBContext db = new DBContext();

        // GET: pedido
        public ActionResult Index()
        {
             return View(db.tb_pedido.OrderByDescending(a =>a.id_pedido).ToList());
        }

        // GET: pedido/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_pedido tb_pedido = db.tb_pedido.Find(id);
            if (tb_pedido == null)
            {
                return HttpNotFound();
            }
            return View(tb_pedido);
        }

        public ActionResult ListaItens()
        {
            return View(db.tb_item.Where(d => d.id_pedido == 1).ToList());
        }

      
       
        // GET: pedido/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: pedido/Create
       [HttpPost]
        public ActionResult Create(string tipo)
         {
            if (ModelState.IsValid)
            {
                tb_pedido tb_pedido = new tb_pedido();
                tb_pedido.valor = 0;
                tb_pedido.valor_venda = 0;
                tb_pedido.status = 0;
                tb_pedido.data = DateTime.Now;
                db.tb_pedido.Add(tb_pedido);
                db.SaveChanges();
            }
            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Finalizar(int pedido)
        {
            if (ModelState.IsValid)
            {
                string cnnString = "data source=(localdb)\\MSSQLLocalDB;initial catalog=master;integrated security=True;MultipleActiveResultSets=True";
                SqlConnection cnn = new SqlConnection(cnnString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnn;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "st_finalizarPedido";
                
                cmd.Parameters.Add("@idPedido", System.Data.SqlDbType.Int);
                cmd.Parameters["@idPedido"].Value = pedido;
              
                cnn.Open();
                object o = cmd.ExecuteScalar();
                cnn.Close();
            }
            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_pedido tb_pedido = db.tb_pedido.Find(id);
            if (tb_pedido == null)
            {
                return HttpNotFound();
            }
            return View(tb_pedido);
        }

        // POST: pedido/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_pedido,data,valor,valor_venda")] tb_pedido tb_pedido)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tb_pedido).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tb_pedido);
        }

        // GET: pedido/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_pedido tb_pedido = db.tb_pedido.Find(id);
            if (tb_pedido == null)
            {
                return HttpNotFound();
            }
            return View(tb_pedido);
        }

        // POST: pedido/Delete/5
        [HttpPost, ActionName("Delete")]
   
        public ActionResult DeleteConfirmed(int id)
        {
            tb_pedido tb_pedido = db.tb_pedido.Find(id);
            db.tb_pedido.Remove(tb_pedido);
            db.SaveChanges();
 
            return Json(new { resultado = "OK" }, JsonRequestBehavior.AllowGet);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
