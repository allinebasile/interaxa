﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using interaxa.Models;

namespace interaxa.Controllers
{
    public class lancheController : Controller
    {
        private DBContext db = new DBContext();

        // GET: lanche
        public ActionResult Index()
        {
            return View(db.tb_lanche.ToList());
        }

        // GET: lanche/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_lanche tb_lanche = db.tb_lanche.Find(id);
            if (tb_lanche == null)
            {
                return HttpNotFound();
            }
            return View(tb_lanche);
        }

        // GET: lanche/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: lanche/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id_lanche,descricao")] tb_lanche tb_lanche)
        {
            if (ModelState.IsValid)
            {
                db.tb_lanche.Add(tb_lanche);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tb_lanche);
        }

        // GET: lanche/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_lanche tb_lanche = db.tb_lanche.Find(id);
            if (tb_lanche == null)
            {
                return HttpNotFound();
            }
            return View(tb_lanche);
        }

        // POST: lanche/Edit/5
      
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id_lanche,descricao")] tb_lanche tb_lanche)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tb_lanche).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tb_lanche);
        }

        // GET: lanche/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tb_lanche tb_lanche = db.tb_lanche.Find(id);
            if (tb_lanche == null)
            {
                return HttpNotFound();
            }
            return View(tb_lanche);
        }

        // POST: lanche/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tb_lanche tb_lanche = db.tb_lanche.Find(id);
            db.tb_lanche.Remove(tb_lanche);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
