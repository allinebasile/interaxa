﻿function SalvarPedido() {


    if (confirm("Deseja adicionar um pedido?")) {
        var url = "/pedido/Create#";

        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: {}
        }).done(function (data) {
         
            if (data.resultado == "OK") {
                alert("Pedido Registrado com Sucesso!");
            }
            else {
                alert("Erro ao Registrar o Pedido!");
            }
        });

        window.location.href += "/pedido/Index";
        location.reload(true);
        $(location).attr('href', "/pedido")
     
    }
    else {
        return false;
    }
}

function ExcluirPedido(pedido) {


    if (confirm("Deseja excluir o pedido " +pedido + "?")) {
        var url = "/pedido/Delete#";

        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: {id:pedido}
        }).done(function (data) {
            if (data.resultado == "OK") {
                alert("Pedido excluído com Sucesso!");
            }
            else {
                alert("Erro ao excluir o Pedido!");
            }
        });

        window.location.href += "/pedido";
        location.reload();
    //    $(location).attr('href', "/pedido")
    }
    else {
        return false;
    }
}

function IncluirLanche() {

    var lanche = $("#id_lanche option:selected").text().trim();
    var idpedido = $("#id_pedido").val();
    var idlanche = $("#id_lanche").val();

    if (confirm("Deseja adicionar um " + lanche + " ao pedido " + idpedido + " ?")) {
        var url = "/item/Create#";


        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: { pedido: idpedido, lanche: idlanche }
        }).done(function (data) {
            if (data.resultado == "OK") {
                alert("Lanche Registrado com Sucesso!");
            }
            else {
                alert("Erro ao Registrar o Lanche!");
            }
        });


        window.location.href += "/pedido";
        location.reload();
        $(location).attr('href', "/pedido")
    }
    else {
        return false;
    }

}

function ExcluirLanche(lanche) {


    if (confirm("Deseja excluir o lanche?")) {
        var url = "/item/Delete#";

        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: { id: lanche }
        }).done(function (data) {
            if (data.resultado == "OK") {
                alert("Lanche excluído com Sucesso!");
            }
            else {
                alert("Erro ao excluir o lanche!");
            }
        });

        window.location.href += "/pedido";
        location.reload();
        //    $(location).attr('href', "/pedido")
    }
    else {
        return false;
    }
}
function FinalizarPedido(pedido) {
    if (confirm("Deseja finalizar o pedido " + pedido + " ?")) {
        var url = "/pedido/Finalizar#";
   
        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: {pedido:pedido}
        }).done(function (data) {
            if (data.resultado == "OK") {
                alert("Pedido Finalizado com Sucesso!");
            }
            else {
                alert("Erro ao Finalizar o Pedido!");
            }
        });

        window.location.href += "/pedido";
        location.reload();
        $(location).attr('href', "/pedido")
    }
    else {
        return false;
    }
}

function Customizar() {

    var descricao = $("#id_ingrediente option:selected").text().trim();
    var iditem = $("#id_item").val();
    var idingrediente = $("#id_ingrediente").val();

    if (confirm("Deseja incluir  o ingrediente " + descricao + " ?")) {
        var url = "/itemIngrediente/Create#";

        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: { item: iditem,ingrediente:idingrediente }
        }).done(function (data) {
            if (data.resultado == "OK") {
                alert("Ingrediente adicionado com Sucesso!");
            }
            else {
                alert("Erro ao Adicionar Ingrediente!");
            }
        });

        window.location.href += "/itemIngrediente/Create";
        location.reload();
      
    }
    else {
        return false;
    }
}

function ExcluirIngrediente(itemIngrediente) {
      

    if (confirm("Deseja excluir  o ingrediente  ?")) {
        var url = "/itemIngrediente/Delete#";

        $.ajax({
            url: url
            , type: "POST"
            , datatype: "json"
            , data: { id: itemIngrediente }
        }).done(function (data) {
            if (data.resultado == "OK") {
                alert("Ingrediente excluído com Sucesso!");
            }
            else {
                alert("Erro ao excluir Ingrediente!");
            }
        });

        window.location.href += "/itemIngrediente/Create";
        location.reload();
      
    }
    else {
        return false;
    }
}





